%declaration des csts
rayon = 2;
a = 2;
b = 0;
c = 0.5;
d = 1;
x0 = 1;
y0 = 1.5;
theta0 = 0;
f  = 0.1;
R = 0.018;
Kp = 5;
a = 0.102;
e = 0.1;
K_delta = -1;

